//Mapbox Public Access Key
mapboxgl.accessToken = 'pk.eyJ1IjoiMjAyMWJpdDA1NSIsImEiOiJjbHJ3YTZ3cjAwdXFhMmxwcXpsaDNsMG1vIn0.Ka47Dr8dv4UAFPb1UPpz0g';

//Initializing map
var map = new mapboxgl.Map({
    //Map Container ID
    container: 'map',
    //Mapbox Style URL
    style: 'mapbox://styles/2021bit055/clt4nozu9000201qyant3d4t8',
    zoom: 12.56, //default zoom
    center: [121.037, 14.332] // default centered coordinate
});

//Search Places
var geocoder = new MapboxGeocoder({
    accessToken: mapboxgl.accessToken,
    marker: true,
});

//Direction Form
var directions = new MapboxDirections({
    accessToken: mapboxgl.accessToken
});

//adding search places on Map
map.addControl(geocoder, 'top-left');

//Adding navigation control on Map
map.addControl(new mapboxgl.NavigationControl(), 'bottom-right');

// Log a message when the map is loaded successfully
map.on('load', function () {
    console.log('Map loaded successfully!');
});
